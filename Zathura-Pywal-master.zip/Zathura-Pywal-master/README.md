# Zathura-Pywal
![alt text](https://i.imgur.com/ETGxlfY.jpg)
![alt text](https://i.imgur.com/qCxiPjD.png)

Zathura-Pywal is a set of helper scripts that dynamically theme zathura based on colors set by [pywal](https://github.com/dylanaraps/pywal).


## Installation

To install, simply move into the clone directory and run `./install.sh`

You can toggle normal colors by pressing `Ctrl+r`
